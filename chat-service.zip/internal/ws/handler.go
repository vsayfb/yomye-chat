package ws

import (
	"context"
	"encoding/json"
	"log/slog"
	"net/http"
	"time"

	"github.com/gorilla/websocket"

	"github.com/vsayfb/gig-platform-chat-service/hub"
	"github.com/vsayfb/gig-platform-chat-service/internal/application"
	"github.com/vsayfb/gig-platform-chat-service/pkg/dto"
	"github.com/vsayfb/gig-platform-chat-service/pkg/grpcclient"
	"github.com/vsayfb/gig-platform-chat-service/pkg/httputil"
	"github.com/vsayfb/gig-platform-chat-service/pkg/jwt"
	"github.com/vsayfb/gig-platform-chat-service/pkg/sqs"

	mysqs "github.com/vsayfb/gig-platform-chat-service/pkg/sqs"
)

var upgrader = websocket.Upgrader{
	ReadBufferSize:  1024,
	WriteBufferSize: 1024,
	CheckOrigin: func(r *http.Request) bool {
		return true // tighten in production
	},
}

// incomingMessage is what the client sends over WebSocket.
type incomingMessage struct {
	Content string `json:"content"`
}

// outgoingMessage is what we deliver to the recipient.
type outgoingMessage struct {
	ThreadID string `json:"thread_id"`
	SenderID string `json:"sender_id"`
	Content  string `json:"content"`
	SentAt   string `json:"sent_at"`
}

type WSHandler struct {
	hub            *hub.Hub
	jwtSvc         *jwt.Service
	applicationSvc application.Service
	userClient     *grpcclient.UserClient
	gigClient      *grpcclient.GigClient
	publisher      *mysqs.Publisher
}

func NewWSHandler(
	h *hub.Hub,
	jwtSvc *jwt.Service,
	applicationSvc application.Service,
	publisher *mysqs.Publisher,
	userClient *grpcclient.UserClient,
	gigClient *grpcclient.GigClient,
) *WSHandler {
	return &WSHandler{
		hub:            h,
		jwtSvc:         jwtSvc,
		applicationSvc: applicationSvc,
		publisher:      publisher,
		userClient:     userClient,
		gigClient:      gigClient,
	}
}

// ServeWS handles WebSocket upgrade and the read loop.
// Query params: token=<jwt>, targetID=<uuid>, gigID=<uuid>
func (h *WSHandler) ServeWS(w http.ResponseWriter, r *http.Request) {

	/* TODO: token=<jwt>, targetID=<uuid>, gigID=<uuid> handles the first message in a thread ever.

	implement e mechanism which accepts connection directly by a threadID because if user will only
	be able to send message to a threaf if he had satisfied token=<jwt>, targetID=<uuid>, gigID=<uuid> step.

	*/
	ctx := r.Context()

	// 1. Authenticate
	token := r.URL.Query().Get("token")

	if token == "" {

		slog.WarnContext(ctx, "invalid token", "err", token)

		httputil.WriteError(w, http.StatusUnauthorized, "missing token")
		return
	}

	claims, err := h.jwtSvc.Verify(token)

	if err != nil {
		slog.WarnContext(ctx, "invalid token", "err", err)

		httputil.WriteError(w, http.StatusUnauthorized, "invalid token")
		return
	}

	senderID := claims.Subject

	sender := &dto.Sender{
		ID:        senderID,
		AvatarURL: claims.AvatarURL,
		Name:      claims.Name,
	}

	// 2. Validate ReceiverID
	receiverID := r.URL.Query().Get("targetID")

	if receiverID == "" {

		slog.WarnContext(ctx, "missing receiverID", "err", err)

		httputil.WriteError(w, http.StatusBadRequest, "missing ReceiverID")
		return
	}

	if sender.ID == receiverID {

		slog.WarnContext(ctx, "cannot connect to yourself", "err", err)

		httputil.WriteError(w, http.StatusConflict, "cannot connect to yourself")
		return
	}

	resp, err := h.userClient.GetUser(ctx, receiverID)

	if err != nil {
		slog.ErrorContext(ctx, "grpc: getUser failed", "err", err)

		httputil.WriteError(w, http.StatusBadRequest, "internal server error")

		return
	}

	Receiver := &dto.Receiver{
		ID:        resp.User.GetId(),
		AvatarURL: resp.GetUser().AvatarUrl,
		Name:      resp.GetUser().Name,
	}

	// 2. Validate gigID
	gigID := r.URL.Query().Get("gigID")

	if gigID == "" {

		slog.WarnContext(ctx, "missing gigID", "err", err)

		httputil.WriteError(w, http.StatusBadRequest, "missing gigID")
		return
	}

	gigResp, err := h.gigClient.GetGig(ctx, gigID)

	if err != nil {
		slog.ErrorContext(ctx, "grpc: getGig failed", "err", err)

		httputil.WriteError(w, http.StatusBadRequest, "internal server error")

		return
	}

	gig := &dto.Gig{
		ID:    gigID,
		Title: gigResp.Gig.GetTitle(),
	}

	// TODO: Do not upgrade if either gig or Receiver exists in database.

	// 3. Upgrade connection
	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		slog.ErrorContext(r.Context(), "ws: upgrade failed", "err", err)
		return
	}

	// 4. Register in Hub
	client := &hub.Client{
		UserID:     senderID,
		ReceiverID: receiverID,
		Conn:       conn,
	}

	h.hub.Register(client)

	slog.InfoContext(r.Context(), "ws: client connected", "userID", senderID, "ReceiverID", receiverID, "gigID", gigID)

	defer func() {
		h.hub.Unregister(senderID)
		conn.Close()
		slog.InfoContext(r.Context(), "ws: client disconnected", "userID", senderID)
	}()

	// 5. Read loop
	for {
		_, raw, err := conn.ReadMessage()

		if err != nil {
			if websocket.IsUnexpectedCloseError(err, websocket.CloseGoingAway, websocket.CloseAbnormalClosure) {
				slog.ErrorContext(r.Context(), "ws: read error", "userID", senderID, "err", err)
			}
			break
		}

		var incoming incomingMessage

		if err := json.Unmarshal(raw, &incoming); err != nil {
			slog.WarnContext(r.Context(), "ws: invalid message format", "userID", senderID)
			continue
		}

		if incoming.Content == "" {
			continue
		}

		h.handleMessage(*sender, *Receiver, *gig, incoming.Content)
	}
}

func (h *WSHandler) handleMessage(
	sender dto.Sender,
	receiver dto.Receiver,
	gig dto.Gig,
	content string,
) {
	// Use a background context since the request context is cancelled when the
	// WebSocket disconnects, but persistence and notification should still complete.
	ctx := context.Background()

	msg, err := h.applicationSvc.SendMessage(
		ctx,
		sender.ID,
		receiver.ID,
		gig.ID,
		content,
	)

	if err != nil {
		slog.ErrorContext(
			ctx,
			"ws: send message failed",
			"sender_id", sender.ID,
			"receiver_id", receiver.ID,
			"gig_id", gig.ID,
			"error", err,
		)

		// TODO: Send structured error back to the sender.
		//
		// Example:
		// {
		//   "type": "error",
		//   "code": "application_pending",
		//   "message": "Waiting for the recipient to approve your application."
		// }

		return
	}

	outgoing := outgoingMessage{
		ThreadID: msg.ThreadID.Hex(),
		SenderID: msg.SenderID,
		Content:  msg.Content,
		SentAt:   msg.SentAt.Format(time.RFC3339),
	}

	payload, err := json.Marshal(outgoing)

	if err != nil {
		slog.ErrorContext(
			ctx,
			"ws: marshal outgoing message failed",
			"thread_id", outgoing.ThreadID,
			"error", err,
		)
		return
	}

	// Deliver immediately if the recipient is online.
	if h.hub.Send(receiver.ID, payload) {
		return
	}

	// Recipient is offline. Publish an event so the notification service
	// can deliver a push notification.

	event := sqs.Envelope{
		Type: mysqs.EventNewMessage,
		Payload: mysqs.NewMessageNotificationEvent{
			RecipientID:    receiver.ID,
			SenderID:       sender.ID,
			SenderName:     sender.Name,
			ThreadID:       outgoing.ThreadID,
			GigID:          gig.ID,
			MessageID:      msg.ID.String(),
			MessagePreview: truncateForNotification(content, 30),
			OccurredAt:     time.Now(),
		}}

	err = h.publisher.PublishNewMessage(ctx, event)

	if err != nil {
		slog.ErrorContext(
			ctx,
			"ws: publish offline notification failed",
			"thread_id", outgoing.ThreadID,
			"receiver_id", receiver.ID,
			"error", err,
		)
	}
}

func truncateForNotification(content string, maxLength int) string {
	runes := []rune(content)

	if len(runes) <= maxLength {
		return content
	}

	if maxLength <= 3 {
		return string(runes[:maxLength])
	}

	return string(runes[:maxLength-3]) + "..."
}
